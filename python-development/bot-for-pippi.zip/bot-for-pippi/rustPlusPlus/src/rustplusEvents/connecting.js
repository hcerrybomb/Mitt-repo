module.exports = {
    name: 'connecting',
    async execute(rustplus, client) {
        rustplus.log('CONNECTING', 'RUSTPLUS CONNECTING...');
    },
};