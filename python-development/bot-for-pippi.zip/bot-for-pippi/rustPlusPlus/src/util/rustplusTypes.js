module.exports = {
    MarkerType: {
        Player: 1,
        Explosion: 2,
        VendingMachine: 3,
        Chinook47: 4,
        CargoShip: 5,
        LockedCrate: 6,
        GenericRadius: 7,
        PatrolHelicopter: 8
    },

}